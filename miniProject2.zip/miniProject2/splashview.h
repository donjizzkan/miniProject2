#ifndef SPLASHVIEW_H
#define SPLASHVIEW_H

#include <QWidget>

class SplashView : public QWidget
{
    Q_OBJECT
public:
    explicit SplashView(QWidget *parent = nullptr);

signals:
};

#endif // SPLASHVIEW_H
